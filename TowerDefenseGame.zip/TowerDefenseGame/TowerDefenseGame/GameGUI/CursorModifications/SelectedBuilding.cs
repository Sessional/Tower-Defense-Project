﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TowerDefenseGame.GameGUI.CursorModifications
{
    class SelectedBuilding
    {
    }
}
