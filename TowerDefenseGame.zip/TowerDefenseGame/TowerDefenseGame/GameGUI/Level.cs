﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TowerDefenseGame.GameGUI
{
    public class Level
    {
        public static int LEVEL_1 = 200, LEVEL_2 = 400, LEVEL_3 = 800, LEVEL_4 = 1600;
    }
}
